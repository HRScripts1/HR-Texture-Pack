HR TEXTURE PACK
Red Dragon Netherite Edition

Contents:
- Red/black custom Netherite armor layer textures
- HR-inspired red pixel-art tool designs
- Animated sample tool texture sheets

Install (Minecraft Java):
1. Keep the ZIP compressed.
2. Move HR_Texture_Pack.zip into .minecraft/resourcepacks.
3. Open Options > Resource Packs and enable it.

IMPORTANT:
- This is a starter Java resource pack, not a server plugin.
- The included animated sample sheets are provided separately; vanilla Minecraft does not automatically use the *_animated.png files.
- Renamed-item-specific textures (for names such as "HR BLOOD REAPER") require a compatible CIT system such as OptiFine CIT or CIT Resewn, plus matching CIT configuration files.
- The armor texture layout and pack format may need adjustment for your exact Minecraft client version. If the pack is rejected, change pack_format in pack.mcmeta to the format required by your client.
- Elytra wing geometry/appearance is not replaced by this starter pack.
